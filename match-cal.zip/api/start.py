def handler(request):
    return {
        "statusCode": 200,
        "body": "Game started!"
    }